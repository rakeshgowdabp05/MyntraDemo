package com.myntrademo.dao.impl;

import com.myntrademo.dao.UserDao;
import com.myntrademo.model.User;
import com.myntrademo.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

public class JdbcUserDao implements UserDao {

    private static final String EXISTS_BY_EMAIL_SQL =
            "SELECT user_id FROM users WHERE email = ? LIMIT 1";

    private static final String EXISTS_BY_PHONE_SQL =
            "SELECT user_id FROM users WHERE phone = ? LIMIT 1";

    private static final String INSERT_USER_SQL =
            """
            INSERT INTO users
            (role_id, full_name, email, phone, password_hash, is_active)
            VALUES (?, ?, ?, ?, ?, TRUE)
            """;

    private static final String INSERT_CART_SQL =
            "INSERT INTO carts (user_id) VALUES (?)";

    private static final String INSERT_WISHLIST_SQL =
            "INSERT INTO wishlists (user_id) VALUES (?)";

    private static final String FIND_BY_EMAIL_FOR_LOGIN_SQL =
            """
            SELECT
                u.user_id,
                u.role_id,
                r.role_name,
                u.full_name,
                u.email,
                u.phone,
                u.password_hash,
                u.is_active
            FROM users u
            INNER JOIN roles r ON u.role_id = r.role_id
            WHERE u.email = ?
            LIMIT 1
            """;

    private static final String UPDATE_LAST_LOGIN_SQL =
            "UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE user_id = ?";

    @Override
    public boolean existsByEmail(String email) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(EXISTS_BY_EMAIL_SQL)) {

            statement.setString(1, email);

            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    @Override
    public boolean existsByPhone(String phone) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(EXISTS_BY_PHONE_SQL)) {

            statement.setString(1, phone);

            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    @Override
    public Long createCustomer(User user) throws SQLException {
        Connection connection = null;

        try {
            connection = DBConnection.getConnection();
            connection.setAutoCommit(false);

            Long userId = insertUser(connection, user);
            insertCart(connection, userId);
            insertWishlist(connection, userId);

            connection.commit();
            return userId;

        } catch (SQLException exception) {
            if (connection != null) {
                connection.rollback();
            }

            throw exception;

        } finally {
            if (connection != null) {
                connection.setAutoCommit(true);
                connection.close();
            }
        }
    }

    @Override
    public Optional<User> findByEmailForLogin(String email) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_BY_EMAIL_FOR_LOGIN_SQL)) {

            statement.setString(1, email);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapLoginUser(resultSet));
                }
            }
        }

        return Optional.empty();
    }

    @Override
    public void updateLastLogin(Long userId) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_LAST_LOGIN_SQL)) {

            statement.setLong(1, userId);
            statement.executeUpdate();
        }
    }

    private Long insertUser(Connection connection, User user) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                INSERT_USER_SQL,
                Statement.RETURN_GENERATED_KEYS
        )) {
            statement.setLong(1, user.getRoleId());
            statement.setString(2, user.getFullName());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getPhone());
            statement.setString(5, user.getPasswordHash());

            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getLong(1);
                }
            }
        }

        throw new SQLException("User creation failed. No generated key returned.");
    }

    private void insertCart(Connection connection, Long userId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(INSERT_CART_SQL)) {
            statement.setLong(1, userId);
            statement.executeUpdate();
        }
    }

    private void insertWishlist(Connection connection, Long userId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(INSERT_WISHLIST_SQL)) {
            statement.setLong(1, userId);
            statement.executeUpdate();
        }
    }

    private User mapLoginUser(ResultSet resultSet) throws SQLException {
        User user = new User();

        user.setUserId(resultSet.getLong("user_id"));
        user.setRoleId(resultSet.getLong("role_id"));
        user.setRoleName(resultSet.getString("role_name"));
        user.setFullName(resultSet.getString("full_name"));
        user.setEmail(resultSet.getString("email"));
        user.setPhone(resultSet.getString("phone"));
        user.setPasswordHash(resultSet.getString("password_hash"));
        user.setActive(resultSet.getBoolean("is_active"));

        return user;
    }
}