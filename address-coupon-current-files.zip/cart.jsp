<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<c:set var="contextPath" value="${pageContext.request.contextPath}" />
<c:set var="currency" value="${empty currencySymbol ? '₹' : currencySymbol}" />
<c:set var="cartAddress" value="${requestScope.cartAddress}" />
<c:set var="availableCoupons" value="${requestScope.availableCoupons}" />

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bag - MyntraDemo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="${contextPath}/assets/css/common/base.css">
    <link rel="stylesheet" href="${contextPath}/assets/css/common/toast.css">
    <link rel="stylesheet" href="${contextPath}/assets/css/cart/cart.css">
</head>
<body>

<%@ include file="/WEB-INF/views/common/toast.jsp" %>

<header class="checkout-header">
    <a href="${contextPath}/products" class="checkout-logo">MD</a>

    <nav class="checkout-steps" aria-label="Checkout steps">
        <span class="is-active">BAG</span>
        <i></i>
        <span>ADDRESS</span>
        <i></i>
        <span>PAYMENT</span>
    </nav>

    <div class="checkout-secure">
        <span></span>
        <strong>100% SECURE</strong>
    </div>
</header>

<main class="cart-page">
    <c:choose>
        <c:when test="${not empty cartPage and cartPage.totalItems gt 0}">
            <section class="cart-shell">
                <section class="cart-left">
                    <section class="cart-address-bar">
                        <c:choose>
                            <c:when test="${not empty cartAddress}">
                                <div>
                                    <span>Deliver to:</span>
                                    <strong>${cartAddress.fullName}, ${cartAddress.pincode}</strong>

                                    <c:if test="${not empty cartAddress.addressLine}">
                                        <p>${cartAddress.addressLine}</p>
                                    </c:if>
                                </div>

                                <a href="${contextPath}/address">CHANGE ADDRESS</a>
                            </c:when>

                            <c:otherwise>
                                <div>
                                    <span>Delivery address</span>
                                    <strong>Add address to continue checkout</strong>
                                </div>

                                <a href="${contextPath}/address">ADD ADDRESS</a>
                            </c:otherwise>
                        </c:choose>
                    </section>

                    <c:if test="${not empty availableCoupons}">
                        <section class="cart-offers-box">
                            <div class="cart-offers-title">
                                <span class="cart-offer-icon"></span>
                                <strong>Offers (${fn:length(availableCoupons)})</strong>
                            </div>

                            <div class="cart-offer-strip">
                                <button type="button" class="cart-offer-arrow" aria-label="Previous offer"></button>

                                <div class="cart-offer-content">
                                    <c:forEach var="coupon" items="${availableCoupons}" begin="0" end="0">
                                        <strong>${coupon.couponTitle}</strong>

                                        <c:if test="${not empty coupon.couponDescription}">
                                            <p>${coupon.couponDescription}</p>
                                        </c:if>
                                    </c:forEach>
                                </div>

                                <button type="button" class="cart-offer-arrow is-next" aria-label="Next offer"></button>
                            </div>
                        </section>
                    </c:if>

                    <section class="cart-selected-row">
                        <div class="cart-selected-left">
                            <span class="cart-check-icon" aria-hidden="true"></span>
                            <strong>${cartPage.totalItems} ITEM(S) SELECTED</strong>
                        </div>

                        <div class="cart-bulk-actions">
                            <a href="${contextPath}/cart">REMOVE</a>
                            <a href="${contextPath}/wishlist">MOVE TO WISHLIST</a>
                        </div>
                    </section>

                    <section class="cart-items-list" aria-label="Bag items">
                        <c:forEach var="item" items="${cartPage.items}">
                            <article class="cart-item-card">
                                <span class="cart-item-check" aria-hidden="true"></span>

                                <a href="${contextPath}/product?id=${item.productId}" class="cart-item-image">
                                    <c:choose>
                                        <c:when test="${item.hasImage()}">
                                            <c:choose>
                                                <c:when test="${fn:startsWith(item.imageUrl, 'http://') or fn:startsWith(item.imageUrl, 'https://')}">
                                                    <img src="${item.imageUrl}" alt="${item.brandName} ${item.productName}">
                                                </c:when>
                                                <c:otherwise>
                                                    <img src="${contextPath}${item.imageUrl}" alt="${item.brandName} ${item.productName}">
                                                </c:otherwise>
                                            </c:choose>
                                        </c:when>

                                        <c:otherwise>
                                            <div class="cart-image-placeholder">Image</div>
                                        </c:otherwise>
                                    </c:choose>
                                </a>

                                <section class="cart-item-info">
                                    <form method="post" action="${contextPath}/cart/remove" class="cart-remove-form">
                                        <input type="hidden" name="cartItemId" value="${item.cartItemId}">
                                        <button type="submit" aria-label="Remove ${item.productName} from bag">Remove</button>
                                    </form>

                                    <a href="${contextPath}/product?id=${item.productId}" class="cart-product-title">
                                        <h2>${item.brandName}</h2>
                                        <p>${item.productName}</p>
                                    </a>

                                    <div class="cart-variant-row">
                                        <span>Size: ${item.displaySize}</span>
                                    </div>

                                    <div class="cart-qty-row">
                                        <form method="post" action="${contextPath}/cart/update" class="cart-qty-form">
                                            <input type="hidden" name="cartItemId" value="${item.cartItemId}">

                                            <label>
                                                Qty:
                                                <select name="quantity" onchange="this.form.submit()">
                                                    <c:choose>
                                                        <c:when test="${item.stockQuantity gt 0}">
                                                            <c:forEach begin="1" end="${item.stockQuantity}" var="qty">
                                                                <option value="${qty}" <c:if test="${qty eq item.quantity}">selected</c:if>>
                                                                    ${qty}
                                                                </option>
                                                            </c:forEach>
                                                        </c:when>

                                                        <c:otherwise>
                                                            <option value="${item.quantity}" selected>${item.quantity}</option>
                                                        </c:otherwise>
                                                    </c:choose>
                                                </select>
                                            </label>
                                        </form>

                                        <c:if test="${item.stockQuantity gt 0 and item.stockQuantity le 5}">
                                            <span class="cart-low-stock">${item.stockQuantity} left</span>
                                        </c:if>
                                    </div>

                                    <div class="cart-price-row">
                                        <strong>
                                            ${currency}<fmt:formatNumber value="${item.priceAtAdded}" maxFractionDigits="0" groupingUsed="false" />
                                        </strong>

                                        <c:if test="${item.hasDiscount()}">
                                            <span>
                                                ${currency}<fmt:formatNumber value="${item.mrpPrice}" maxFractionDigits="0" groupingUsed="false" />
                                            </span>

                                            <em>
                                                ${currency}<fmt:formatNumber value="${item.itemDiscountTotal}" maxFractionDigits="0" groupingUsed="false" />
                                                OFF
                                            </em>
                                        </c:if>
                                    </div>

                                    <div class="cart-item-actions">
                                        <form method="post" action="${contextPath}/cart/move-to-wishlist">
                                            <input type="hidden" name="cartItemId" value="${item.cartItemId}">
                                            <button type="submit">MOVE TO WISHLIST</button>
                                        </form>
                                    </div>
                                </section>
                            </article>
                        </c:forEach>
                    </section>
                </section>

                <aside class="cart-right" aria-label="Price details">
                    <section class="cart-side-section">
                        <h2>OFFERS & COUPONS</h2>

                        <c:choose>
                            <c:when test="${not empty availableCoupons}">
                                <a href="${contextPath}/coupons" class="cart-coupon-banner">
                                    <span class="cart-coupon-icon"></span>
                                    <strong>${fn:length(availableCoupons)} Offer<c:if test="${fn:length(availableCoupons) gt 1}">s</c:if> On Your Bag</strong>
                                    <em></em>
                                </a>
                            </c:when>

                            <c:otherwise>
                                <a href="${contextPath}/coupons" class="cart-coupon-banner">
                                    <span class="cart-coupon-icon"></span>
                                    <strong>Apply available coupons</strong>
                                    <em></em>
                                </a>
                            </c:otherwise>
                        </c:choose>

                        <div class="cart-apply-row">
                            <div>
                                <span class="cart-tag-icon"></span>
                                <strong>Apply Coupons</strong>
                            </div>
                            <a href="${contextPath}/coupons">APPLY</a>
                        </div>
                    </section>

                    <section class="cart-price-card">
                        <h2>PRICE DETAILS (${cartPage.totalItems} Item<c:if test="${cartPage.totalItems gt 1}">s</c:if>)</h2>

                        <div class="cart-price-line">
                            <span>Total MRP</span>
                            <strong>
                                ${currency}<fmt:formatNumber value="${cartPage.totalMrp}" maxFractionDigits="0" groupingUsed="false" />
                            </strong>
                        </div>

                        <c:if test="${cartPage.discountAvailable}">
                            <div class="cart-price-line">
                                <span>Discount on MRP</span>
                                <strong class="cart-green">
                                    - ${currency}<fmt:formatNumber value="${cartPage.totalDiscount}" maxFractionDigits="0" groupingUsed="false" />
                                </strong>
                            </div>
                        </c:if>

                        <div class="cart-price-line">
                            <span>Coupon Discount</span>
                            <a href="${contextPath}/coupons" class="cart-pink">Apply Coupon</a>
                        </div>

                        <div class="cart-total-line">
                            <span>Total Amount</span>
                            <strong>
                                ${currency}<fmt:formatNumber value="${cartPage.subtotal}" maxFractionDigits="0" groupingUsed="false" />
                            </strong>
                        </div>

                        <a href="${contextPath}/checkout" class="cart-place-order-btn">
                            PLACE ORDER
                        </a>
                    </section>
                </aside>
            </section>

            <c:if test="${cartPage.recommendedProductsAvailable}">
                <section class="cart-recommend-section">
                    <div class="cart-recommend-header">
                        <h2>You may also like</h2>
                    </div>

                    <div class="cart-recommend-grid">
                        <c:forEach var="product" items="${cartPage.recommendedProducts}">
                            <article class="cart-recommend-card">
                                <a href="${contextPath}/product?id=${product.productId}" class="cart-recommend-image">
                                    <c:choose>
                                        <c:when test="${product.imageAvailable}">
                                            <c:choose>
                                                <c:when test="${fn:startsWith(product.imageUrl, 'http://') or fn:startsWith(product.imageUrl, 'https://')}">
                                                    <img src="${product.imageUrl}" alt="${product.brandName} ${product.productName}">
                                                </c:when>
                                                <c:otherwise>
                                                    <img src="${contextPath}${product.imageUrl}" alt="${product.brandName} ${product.productName}">
                                                </c:otherwise>
                                            </c:choose>
                                        </c:when>

                                        <c:otherwise>
                                            <div class="cart-recommend-placeholder">Image</div>
                                        </c:otherwise>
                                    </c:choose>
                                </a>

                                <div class="cart-recommend-info">
                                    <h3>${product.brandName}</h3>
                                    <p>${product.productName}</p>

                                    <div class="cart-recommend-price">
                                        <strong>
                                            ${currency}<fmt:formatNumber value="${product.sellingPrice}" maxFractionDigits="0" groupingUsed="false" />
                                        </strong>

                                        <c:if test="${product.discounted}">
                                            <span>
                                                ${currency}<fmt:formatNumber value="${product.mrpPrice}" maxFractionDigits="0" groupingUsed="false" />
                                            </span>
                                            <em>(${product.discountPercent}% OFF)</em>
                                        </c:if>
                                    </div>

                                    <a href="${contextPath}/product?id=${product.productId}" class="cart-recommend-action">
                                        VIEW PRODUCT
                                    </a>
                                </div>
                            </article>
                        </c:forEach>
                    </div>
                </section>
            </c:if>
        </c:when>

        <c:otherwise>
            <section class="cart-empty-state">
                <div class="cart-empty-icon" aria-hidden="true"></div>
                <h1>Your bag is empty</h1>
                <p>Add products from the catalog to see them here.</p>
                <a href="${contextPath}/products" class="md-btn md-btn-primary">CONTINUE SHOPPING</a>
            </section>
        </c:otherwise>
    </c:choose>
</main>

<script src="${contextPath}/assets/js/common/toast.js"></script>
</body>
</html>