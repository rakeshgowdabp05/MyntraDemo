package com.myntrademo.service.impl;

import com.myntrademo.constant.MessageConstants;
import com.myntrademo.dao.CartDao;
import com.myntrademo.dao.impl.JdbcCartDao;
import com.myntrademo.dto.cart.AddToCartRequest;
import com.myntrademo.dto.cart.CartItemDto;
import com.myntrademo.dto.cart.CartPageDto;
import com.myntrademo.dto.cart.RecommendedProductDto;
import com.myntrademo.service.CartService;

import java.sql.SQLException;
import java.util.List;

public class CartServiceImpl implements CartService {

    private static final int RECOMMENDED_PRODUCT_LIMIT = 15;

    private final CartDao cartDao;

    public CartServiceImpl() {
        this.cartDao = new JdbcCartDao();
    }

    public CartServiceImpl(CartDao cartDao) {
        this.cartDao = cartDao;
    }

    @Override
    public void addToCart(Long userId, AddToCartRequest request) throws SQLException {
        validateUser(userId);
        validateAddToCartRequest(request);

        cartDao.addItem(userId, request);
    }

    @Override
    public CartPageDto getCartPage(Long userId) throws SQLException {
        validateUser(userId);

        List<CartItemDto> cartItems = cartDao.findCartItems(userId);
        List<RecommendedProductDto> recommendedProducts = cartDao.findRecommendedProducts(
                userId,
                RECOMMENDED_PRODUCT_LIMIT
        );

        return new CartPageDto(cartItems, recommendedProducts);
    }

    @Override
    public void updateQuantity(Long userId, Long cartItemId, int quantity) throws SQLException {
        validateUser(userId);

        if (cartItemId == null) {
            throw new IllegalArgumentException(MessageConstants.CART_ITEM_NOT_FOUND);
        }

        if (quantity <= 0) {
            throw new IllegalArgumentException(MessageConstants.INVALID_CART_QUANTITY);
        }

        cartDao.updateItemQuantity(userId, cartItemId, quantity);
    }

    @Override
    public void removeItem(Long userId, Long cartItemId) throws SQLException {
        validateUser(userId);

        if (cartItemId == null) {
            throw new IllegalArgumentException(MessageConstants.CART_ITEM_NOT_FOUND);
        }

        cartDao.removeItem(userId, cartItemId);
    }

    private void validateUser(Long userId) {
        if (userId == null) {
            throw new IllegalArgumentException(MessageConstants.AUTH_REQUIRED);
        }
    }

    private void validateAddToCartRequest(AddToCartRequest request) {
        if (request == null || request.getProductId() == null || request.getVariantId() == null) {
            throw new IllegalArgumentException(MessageConstants.SELECT_PRODUCT_VARIANT);
        }

        if (request.getQuantity() <= 0) {
            throw new IllegalArgumentException(MessageConstants.INVALID_CART_QUANTITY);
        }
    }
}